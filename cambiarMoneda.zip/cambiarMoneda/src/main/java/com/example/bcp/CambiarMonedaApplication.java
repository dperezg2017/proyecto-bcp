package com.example.bcp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CambiarMonedaApplication {

	public static void main(String[] args) {
		SpringApplication.run(CambiarMonedaApplication.class, args);
	}

}
